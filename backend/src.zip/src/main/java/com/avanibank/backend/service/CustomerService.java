package com.avanibank.backend.service;

import com.avanibank.backend.dto.RegisterRequest;
import com.avanibank.backend.entity.Customer;
import com.avanibank.backend.repository.CustomerRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;
    private final PasswordEncoder passwordEncoder;

    private String generateAccountNumber() {

    long number = 1000000000L
            + (long) (Math.random() * 9000000000L);

    return String.valueOf(number);
}

    public CustomerService(
            CustomerRepository customerRepository,
            PasswordEncoder passwordEncoder) {

        this.customerRepository = customerRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // =========================
// REGISTER CUSTOMER
// =========================
public Customer registerCustomer(RegisterRequest request) {

    if (customerRepository.existsByEmail(request.getEmail())) {
        throw new RuntimeException("Email already registered");
    }

    if (customerRepository.existsByPhone(request.getPhone())) {
        throw new RuntimeException("Phone number already registered");
    }

    Customer customer = new Customer();

    customer.setFullName(request.getFullName());
    customer.setEmail(request.getEmail());
    customer.setPhone(request.getPhone());

    customer.setPassword(
            passwordEncoder.encode(request.getPassword())
    );

    customer.setAccountType(request.getAccountType());

    // Initial values
    customer.setBalance(0.0);
    customer.setStatus("ACTIVE");

    // Automatically generate unique account number
    String accountNumber;

    do {
        accountNumber = generateAccountNumber();
    } while (
            customerRepository.existsByAccountNumber(accountNumber)
    );

    customer.setAccountNumber(accountNumber);

    return customerRepository.save(customer);
    }

    // =========================
    // CREATE CUSTOMER
    // =========================
    public Customer createCustomer(Customer customer) {

        if (customerRepository.existsByEmail(customer.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        if (customerRepository.existsByPhone(customer.getPhone())) {
            throw new RuntimeException("Phone number already registered");
        }

        if (customerRepository.existsByAccountNumber(
                customer.getAccountNumber())) {

            throw new RuntimeException("Account number already exists");
        }

        // Encrypt password before saving
        customer.setPassword(
                passwordEncoder.encode(customer.getPassword())
        );

        return customerRepository.save(customer);
    }


    // =========================
    // GET ALL CUSTOMERS
    // =========================
    public List<Customer> getAllCustomers() {

        return customerRepository.findAll();
    }


    // =========================
    // GET CUSTOMER BY ID
    // =========================
    public Customer getCustomerById(Long id) {

        return customerRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Customer not found"));
    }


    // =========================
    // GET CUSTOMER BY EMAIL
    // =========================
    public Customer getCustomerByEmail(String email) {

        return customerRepository.findByEmail(email)
                .orElseThrow(() ->
                        new RuntimeException("Customer not found"));
    }


    // =========================
    // UPDATE CUSTOMER
    // =========================
    public Customer updateCustomer(
            Long id,
            Customer updatedCustomer) {

        Customer existingCustomer =
                getCustomerById(id);

        existingCustomer.setFullName(
                updatedCustomer.getFullName()
        );

        existingCustomer.setPhone(
                updatedCustomer.getPhone()
        );

        existingCustomer.setAccountType(
                updatedCustomer.getAccountType()
        );

        existingCustomer.setStatus(
                updatedCustomer.getStatus()
        );

        return customerRepository.save(existingCustomer);
    }

    // =========================
// CHANGE PASSWORD
// =========================
public void changePassword(
        String email,
        String currentPassword,
        String newPassword) {

    Customer customer = customerRepository.findByEmail(email)
            .orElseThrow(() ->
                    new RuntimeException("Customer not found"));

    // Check current password
    if (!passwordEncoder.matches(
            currentPassword,
            customer.getPassword())) {

        throw new RuntimeException(
                "Current password is incorrect"
        );
    }

    // Validate new password
    if (newPassword == null || newPassword.trim().isEmpty()) {
        throw new RuntimeException(
                "New password cannot be empty"
        );
    }

    if (newPassword.length() < 6) {
        throw new RuntimeException(
                "New password must be at least 6 characters"
        );
    }

    // Prevent same password
    if (passwordEncoder.matches(
            newPassword,
            customer.getPassword())) {

        throw new RuntimeException(
                "New password must be different from current password"
        );
    }

    // Encrypt new password
    customer.setPassword(
            passwordEncoder.encode(newPassword)
    );

    customerRepository.save(customer);
    }

    // =========================
    // DELETE CUSTOMER
    // =========================
    public void deleteCustomer(Long id) {

        Customer customer =
                getCustomerById(id);

        customerRepository.delete(customer);
    }
}
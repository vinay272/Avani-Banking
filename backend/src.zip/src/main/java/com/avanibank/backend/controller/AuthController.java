package com.avanibank.backend.controller;

import com.avanibank.backend.dto.LoginRequest;
import com.avanibank.backend.dto.LoginResponse;
import com.avanibank.backend.dto.RegisterRequest;
import com.avanibank.backend.entity.Customer;
import com.avanibank.backend.service.AuthService;
import com.avanibank.backend.service.CustomerService;
import com.avanibank.backend.service.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final AuthService authService;
    private final JwtService jwtService;
    private final CustomerService customerService;

    public AuthController(
            AuthService authService,
            JwtService jwtService,
            CustomerService customerService) {

        this.authService = authService;
        this.jwtService = jwtService;
        this.customerService = customerService;
    }

    // =========================
    // LOGIN
    // =========================
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(
            @RequestBody LoginRequest request) {

        Customer customer = authService.login(
                request.getEmail(),
                request.getPassword()
        );

        String token = jwtService.generateToken(
                customer.getEmail()
        );

        return ResponseEntity.ok(
                new LoginResponse(
                        "Login successful",
                        token,
                        customer
                )
        );
    }

    // =========================
    // REGISTER
    // =========================
    @PostMapping("/register")
    public ResponseEntity<Customer> register(
            @RequestBody RegisterRequest request) {

        Customer customer =
                customerService.registerCustomer(request);

        return new ResponseEntity<>(
                customer,
                HttpStatus.CREATED
        );
    }
}
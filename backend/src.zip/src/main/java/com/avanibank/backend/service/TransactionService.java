package com.avanibank.backend.service;

import com.avanibank.backend.dto.TransferRequest;
import com.avanibank.backend.entity.Customer;
import com.avanibank.backend.entity.Transaction;
import com.avanibank.backend.repository.CustomerRepository;
import com.avanibank.backend.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TransactionService {

    private final CustomerRepository customerRepository;
    private final TransactionRepository transactionRepository;

    public TransactionService(
            CustomerRepository customerRepository,
            TransactionRepository transactionRepository) {

        this.customerRepository = customerRepository;
        this.transactionRepository = transactionRepository;
    }

    // Transfer Money
    @Transactional
    public Transaction transferMoney(
            String senderEmail,
            TransferRequest request) {

        // Validate amount
        if (request.getAmount() == null || request.getAmount() <= 0) {
            throw new RuntimeException("Transfer amount must be greater than 0");
        }

        // Find sender using logged-in email
        Customer sender = customerRepository
                .findByEmail(senderEmail)
                .orElseThrow(() ->
                        new RuntimeException("Sender account not found"));

        // Find receiver
        Customer receiver = customerRepository
                .findByAccountNumber(request.getReceiverAccountNumber())
                .orElseThrow(() ->
                        new RuntimeException("Receiver account not found"));

        // Prevent self transfer
        if (sender.getAccountNumber()
                .equals(receiver.getAccountNumber())) {

            throw new RuntimeException(
                    "You cannot transfer money to your own account");
        }

        // Check balance
        if (sender.getBalance() < request.getAmount()) {
            throw new RuntimeException("Insufficient balance");
        }

        // Debit sender
        sender.setBalance(
                sender.getBalance() - request.getAmount()
        );

        // Credit receiver
        receiver.setBalance(
                receiver.getBalance() + request.getAmount()
        );

        // Save updated customers
        customerRepository.save(sender);
        customerRepository.save(receiver);

        // Create transaction record
        Transaction transaction = new Transaction();

        transaction.setSenderAccountNumber(
                sender.getAccountNumber()
        );

        transaction.setReceiverAccountNumber(
                receiver.getAccountNumber()
        );

        transaction.setAmount(request.getAmount());

        transaction.setTransactionType("TRANSFER");

        transaction.setStatus("SUCCESS");

        return transactionRepository.save(transaction);
    }

    // Get transactions sent by customer
    public List<Transaction> getSentTransactions(
            String accountNumber) {

        return transactionRepository
                .findBySenderAccountNumberOrderByTransactionDateDesc(
                        accountNumber
                );
    }

    // Get transactions received by customer
    public List<Transaction> getReceivedTransactions(
            String accountNumber) {

        return transactionRepository
                .findByReceiverAccountNumberOrderByTransactionDateDesc(
                        accountNumber
                );
    }
}
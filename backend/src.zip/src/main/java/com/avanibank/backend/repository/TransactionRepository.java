package com.avanibank.backend.repository;

import com.avanibank.backend.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findBySenderAccountNumberOrderByTransactionDateDesc(
            String senderAccountNumber
    );

    List<Transaction> findByReceiverAccountNumberOrderByTransactionDateDesc(
            String receiverAccountNumber
    );
}

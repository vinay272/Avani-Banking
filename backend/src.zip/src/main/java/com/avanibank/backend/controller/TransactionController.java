package com.avanibank.backend.controller;

import com.avanibank.backend.dto.TransferRequest;
import com.avanibank.backend.entity.Customer;
import com.avanibank.backend.entity.Transaction;
import com.avanibank.backend.service.CustomerService;
import com.avanibank.backend.service.TransactionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@CrossOrigin(origins = "*")
public class TransactionController {

    private final TransactionService transactionService;
    private final CustomerService customerService;

    public TransactionController(
            TransactionService transactionService,
            CustomerService customerService) {

        this.transactionService = transactionService;
        this.customerService = customerService;
    }

    // Transfer Money
    @PostMapping("/transfer")
    public ResponseEntity<Transaction> transferMoney(
            @RequestBody TransferRequest request) {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        Transaction transaction =
                transactionService.transferMoney(email, request);

        return ResponseEntity.ok(transaction);
    }

    // Get My Sent Transactions
    @GetMapping("/sent")
    public ResponseEntity<List<Transaction>> getSentTransactions() {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        Customer customer =
                customerService.getCustomerByEmail(email);

        return ResponseEntity.ok(
                transactionService.getSentTransactions(
                        customer.getAccountNumber()
                )
        );
    }

    // Get My Received Transactions
    @GetMapping("/received")
    public ResponseEntity<List<Transaction>> getReceivedTransactions() {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        Customer customer =
                customerService.getCustomerByEmail(email);

        return ResponseEntity.ok(
                transactionService.getReceivedTransactions(
                        customer.getAccountNumber()
                )
        );
    }
}
package com.avanibank.backend.service;

import com.avanibank.backend.entity.Customer;
import com.avanibank.backend.entity.KycDocument;
import com.avanibank.backend.repository.CustomerRepository;
import com.avanibank.backend.repository.KycDocumentRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class KycDocumentService {

        private final KycDocumentRepository kycDocumentRepository;
        private final CustomerRepository customerRepository;

        public KycDocumentService(
                        KycDocumentRepository kycDocumentRepository,
                        CustomerRepository customerRepository) {

                this.kycDocumentRepository = kycDocumentRepository;
                this.customerRepository = customerRepository;
        }

        // =========================
        // UPLOAD KYC DOCUMENT
        // =========================

        public KycDocument uploadKycDocument(
                        Long customerId,
                        String documentType,
                        String documentNumber) {

                Customer customer = customerRepository.findById(customerId)
                                .orElseThrow(() -> new RuntimeException("Customer not found"));

                if (documentType == null || documentType.isBlank()) {
                        throw new RuntimeException("Document type is required");
                }

                if (documentNumber == null || documentNumber.isBlank()) {
                        throw new RuntimeException("Document number is required");
                }

                if (kycDocumentRepository
                                .existsByCustomerAndDocumentType(
                                                customer,
                                                documentType)) {

                        throw new RuntimeException(
                                        "This document type is already registered");
                }

                KycDocument document = new KycDocument();

                document.setCustomer(customer);
                document.setDocumentType(documentType.toUpperCase());
                document.setDocumentNumber(documentNumber);
                document.setVerificationStatus("PENDING");
                document.setUploadedAt(LocalDateTime.now());

                return kycDocumentRepository.save(document);
        }

        // =========================
        // GET CUSTOMER KYC DOCUMENTS
        // =========================

        public List<KycDocument> getCustomerDocuments(
                        Long customerId) {

                Customer customer = customerRepository.findById(customerId)
                                .orElseThrow(() -> new RuntimeException("Customer not found"));

                return kycDocumentRepository.findByCustomer(customer);
        }

        // =========================
        // VERIFY KYC DOCUMENT
        // =========================

        public KycDocument verifyDocument(
                        Long documentId,
                        String status,
                        String remarks) {

                KycDocument document = kycDocumentRepository.findById(documentId)
                                .orElseThrow(() -> new RuntimeException(
                                                "KYC document not found"));

                if (!status.equalsIgnoreCase("VERIFIED")
                                && !status.equalsIgnoreCase("REJECTED")) {

                        throw new RuntimeException(
                                        "Status must be VERIFIED or REJECTED");
                }

              
                document.setVerificationStatus(
                                status.toUpperCase());

                document.setVerificationRemarks(remarks);

                document.setVerifiedAt(
                                LocalDateTime.now());

                KycDocument savedDocument = kycDocumentRepository.save(document);

                updateCustomerKycStatus(document.getCustomer());

                return savedDocument;
        }
        private void updateCustomerKycStatus(Customer customer) {

    List<KycDocument> documents =
            kycDocumentRepository.findByCustomer(customer);

    if (documents.isEmpty()) {
        customer.setKycStatus("PENDING");
        customerRepository.save(customer);
        return;
    }

    boolean anyRejected = documents.stream()
            .anyMatch(document ->
                    "REJECTED".equalsIgnoreCase(
                            document.getVerificationStatus()
                    )
            );

    boolean allVerified = documents.stream()
            .allMatch(document ->
                    "VERIFIED".equalsIgnoreCase(
                            document.getVerificationStatus()
                    )
            );

    if (anyRejected) {

        customer.setKycStatus("REJECTED");

    } else if (allVerified) {

        customer.setKycStatus("VERIFIED");

    } else {

        customer.setKycStatus("PENDING");
    }

    customerRepository.save(customer);
}
}
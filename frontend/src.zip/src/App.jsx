import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import TransferMoney from "./pages/TransferMoney";
import Register from "./pages/Register";
import ProtectedRoute from "./components/ProtectedRoute";
import TransactionHistory from "./pages/TransactionHistory";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Nominee from "./pages/Nominee";
import KYC from "./pages/KYC";
import CustomerRiskProfile from "./pages/CustomerRiskProfile";
import AddressVerification from "./pages/AddressVerification";
import DuplicateKyc from "./pages/DuplicateKyc";
import JointAccount from "./pages/JointAccount";
import CustomerRelationshipHistory from "./pages/CustomerRelationshipHistory";
import BiometricVerification from "./pages/BiometricVerification";
import AmlCheck from "./pages/AmlCheck";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* =========================
            DEFAULT ROUTE
        ========================= */}

        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* =========================
            PUBLIC ROUTES
        ========================= */}

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />

        {/* =========================
            PROTECTED ROUTES
        ========================= */}

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/transfer"
          element={
            <ProtectedRoute>
              <TransferMoney />
            </ProtectedRoute>
          }
        />

        <Route
          path="/transactions"
          element={
            <ProtectedRoute>
              <TransactionHistory />
            </ProtectedRoute>
          }
        />

        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route
          path="/nominee"
          element={
            <ProtectedRoute>
              <Nominee />
            </ProtectedRoute>
          }
        />
        <Route path="/kyc" element={<KYC />} />
        <Route path="/risk-profile" element={<CustomerRiskProfile />} />
        <Route path="/address-verification" element={<AddressVerification />} />
        <Route path="/duplicate-kyc" element={<DuplicateKyc />} />
        <Route path="/joint-account" element={<JointAccount />} />
        <Route path="/customer-relationship-history"element={<CustomerRelationshipHistory />}/>
        <Route path="/aml-check" element={<AmlCheck />} />
        <Route
          path="/biometric-verification"
          element={<BiometricVerification />}
        />

        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <Settings />
            </ProtectedRoute>
          }
        />

        {/* =========================
            UNKNOWN ROUTE
        ========================= */}

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

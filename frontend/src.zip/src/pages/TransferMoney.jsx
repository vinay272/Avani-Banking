import { useState } from "react";
import { useNavigate } from "react-router-dom";

function TransferMoney() {
  const navigate = useNavigate();
  const [receiverAccountNumber, setReceiverAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleTransfer = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");

    if (!receiverAccountNumber.trim()) {
      setError("Please enter receiver account number.");
      return;
    }

    if (!amount || Number(amount) <= 0) {
      setError("Please enter a valid amount.");
      return;
    }

    const token = localStorage.getItem("token");

    if (!token) {
      setError("Login session expired. Please login again.");
      return;
    }

    try {
      setLoading(true);

      const response = await fetch(
        "http://localhost:8080/api/transactions/transfer",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            receiverAccountNumber: receiverAccountNumber.trim(),
            amount: Number(amount),
          }),
        },
      );

      //   const data = await response.json();

      //   if (!response.ok) {
      //     throw new Error(
      //       data.message || "Transfer failed. Please try again."
      //     );
      //   }
      const responseText = await response.text();

      let data = {};

      try {
        data = responseText ? JSON.parse(responseText) : {};
      } catch {
        data = { message: responseText };
      }

      if (!response.ok) {
        throw new Error(data.message || "Transfer failed. Please try again.");
      }
      setMessage("Money transferred successfully.");
      setReceiverAccountNumber("");
      setAmount("");
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <div>
            <p style={styles.smallTitle}>AVANI BANK</p>
            <h1 style={styles.title}>Transfer Money</h1>
            <p style={styles.subtitle}>
              Send money securely to another Avani Bank account.
            </p>
          </div>
          <div style={styles.headerRight}>
            <button
              onClick={() => navigate("/dashboard")}
              style={styles.dashboardButton}
            >
              ← Dashboard
            </button>
            <div style={styles.icon}>⇄</div>
          </div>
        </div>

        <div style={styles.card}>
          <div style={styles.cardHeader}>
            <h2 style={styles.cardTitle}>Make a Transfer</h2>
            <span style={styles.secure}>🔒 Secure</span>
          </div>

          <form onSubmit={handleTransfer}>
            <div style={styles.field}>
              <label style={styles.label}>Receiver Account Number</label>

              <input
                type="text"
                value={receiverAccountNumber}
                onChange={(e) => setReceiverAccountNumber(e.target.value)}
                placeholder="Enter receiver account number"
                style={styles.input}
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Transfer Amount</label>

              <div style={styles.amountBox}>
                <span style={styles.currency}>₹</span>

                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="1"
                  step="0.01"
                  style={styles.amountInput}
                />
              </div>
            </div>

            {message && <div style={styles.success}>✓ {message}</div>}

            {error && <div style={styles.error}>⚠ {error}</div>}

            <button
              type="submit"
              disabled={loading}
              style={{
                ...styles.button,
                opacity: loading ? 0.7 : 1,
                cursor: loading ? "not-allowed" : "pointer",
              }}
            >
              {loading ? "Processing..." : "Transfer Money →"}
            </button>
          </form>
        </div>

        <div style={styles.infoGrid}>
          <div style={styles.infoCard}>
            <div style={styles.infoIcon}>🛡️</div>
            <div>
              <h3 style={styles.infoTitle}>Secure Transfer</h3>
              <p style={styles.infoText}>
                Your transaction is processed securely.
              </p>
            </div>
          </div>

          <div style={styles.infoCard}>
            <div style={styles.infoIcon}>⚡</div>
            <div>
              <h3 style={styles.infoTitle}>Instant Processing</h3>
              <p style={styles.infoText}>
                Money is transferred instantly between accounts.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f5f7fb",
    fontFamily: "Inter, Arial, sans-serif",
    color: "#172033",
    boxSizing: "border-box",
  },

  container: {
    width: "100%",
    maxWidth: "850px",
    margin: "0 auto",
    padding: "40px 20px",
    boxSizing: "border-box",
  },

  header: {
    background:
      "linear-gradient(135deg, #102354 0%, #173b8c 55%, #2457c6 100%)",
    color: "white",
    borderRadius: "20px",
    padding: "30px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "20px",
    boxSizing: "border-box",
    boxShadow: "0 15px 35px rgba(18,51,120,0.18)",
  },

  dashboardButton: {
    border: "1px solid rgba(255,255,255,0.25)",
    background: "rgba(255,255,255,0.10)",
    color: "white",
    borderRadius: "9px",
    padding: "10px 14px",
    fontSize: "11px",
    fontWeight: "700",
    cursor: "pointer",
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    marginLeft: "auto",
  },
  smallTitle: {
    margin: 0,
    fontSize: "11px",
    letterSpacing: "2px",
    opacity: 0.7,
    fontWeight: "700",
  },

  title: {
    margin: "8px 0 5px",
    fontSize: "30px",
  },

  subtitle: {
    margin: 0,
    fontSize: "13px",
    color: "#d7e2ff",
  },

  icon: {
    width: "55px",
    height: "55px",
    borderRadius: "15px",
    background: "rgba(255,255,255,0.13)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "25px",
    flexShrink: 0,
  },

  card: {
    background: "white",
    marginTop: "22px",
    padding: "30px",
    borderRadius: "18px",
    border: "1px solid #e9edf4",
    boxShadow: "0 8px 30px rgba(20,35,70,0.06)",
    boxSizing: "border-box",
  },

  cardHeader: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "15px",
    marginBottom: "25px",
  },

  cardTitle: {
    margin: 0,
    fontSize: "20px",
    color: "black",
  },

  secure: {
    fontSize: "11px",
    color: "#168653",
    background: "#eaf8f0",
    padding: "7px 10px",
    borderRadius: "8px",
    fontWeight: "600",
  },

  field: {
    marginBottom: "20px",
  },

  label: {
    display: "block",
    marginBottom: "8px",
    fontSize: "12px",
    fontWeight: "700",
    color: "#526078",
  },

  input: {
    width: "100%",
    height: "50px",
    padding: "0 15px",
    border: "1px solid #dfe5ee",
    borderRadius: "10px",
    outline: "none",
    fontSize: "14px",
    boxSizing: "border-box",
  },

  amountBox: {
    height: "50px",
    display: "flex",
    alignItems: "center",
    border: "1px solid #dfe5ee",
    borderRadius: "10px",
    padding: "0 15px",
    boxSizing: "border-box",
    background: "#3a3c41",
  },

  currency: {
    fontSize: "18px",
    fontWeight: "700",
    color: "#f6f8fd",
  },

  amountInput: {
    width: "100%",
    height: "46px",
    border: "none",
    outline: "none",
    padding: "0 10px",
    fontSize: "18px",
    boxSizing: "border-box",
  },

  button: {
    width: "100%",
    height: "50px",
    border: "none",
    borderRadius: "10px",
    background: "linear-gradient(135deg, #173b8c, #2563c7)",
    color: "white",
    fontSize: "14px",
    fontWeight: "700",
    marginTop: "5px",
  },

  success: {
    padding: "12px 14px",
    borderRadius: "9px",
    background: "#eaf8f0",
    color: "#168653",
    fontSize: "12px",
    marginBottom: "15px",
  },

  error: {
    padding: "12px 14px",
    borderRadius: "9px",
    background: "#fff0f0",
    color: "#d13c3c",
    fontSize: "12px",
    marginBottom: "15px",
  },

  infoGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "15px",
    marginTop: "18px",
  },

  infoCard: {
    background: "white",
    border: "1px solid #e9edf4",
    borderRadius: "14px",
    padding: "18px",
    display: "flex",
    alignItems: "center",
    gap: "13px",
    boxSizing: "border-box",
  },

  infoIcon: {
    width: "40px",
    height: "40px",
    borderRadius: "10px",
    background: "#edf3ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },

  infoTitle: {
    margin: 0,
    fontSize: "13px",
  },

  infoText: {
    margin: "4px 0 0",
    fontSize: "10px",
    color: "#8993a8",
    lineHeight: "1.5",
  },
};

export default TransferMoney;

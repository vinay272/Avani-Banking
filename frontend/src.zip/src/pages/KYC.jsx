import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function KYC() {
  const navigate = useNavigate();

  const [customer, setCustomer] = useState(null);
  const [documents, setDocuments] = useState([]);

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const [formData, setFormData] = useState({
    documentType: "",
    documentNumber: "",
  });

  const token = localStorage.getItem("token");

  // =========================
  // LOAD CUSTOMER + KYC
  // =========================

  useEffect(() => {
    loadKycData();
  }, []);

  const loadKycData = async () => {
    try {
      setLoading(true);
      setError("");

      // Get logged-in customer
      const customerResponse = await fetch(
        "http://localhost:8080/api/customers/me",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!customerResponse.ok) {
        throw new Error("Unable to fetch customer details.");
      }

      const customerData = await customerResponse.json();

      setCustomer(customerData);

      // Get customer KYC documents
      const kycResponse = await fetch(
        `http://localhost:8080/api/kyc/customer/${customerData.id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!kycResponse.ok) {
        throw new Error("Unable to fetch KYC details.");
      }

      const kycData = await kycResponse.json();

      setDocuments(kycData);
    } catch (err) {
      console.error("KYC loading error:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // FORM CHANGE
  // =========================

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // =========================
  // RESET FORM
  // =========================

  const resetForm = () => {
    setFormData({
      documentType: "",
      documentNumber: "",
    });
  };

  // =========================
  // SUBMIT KYC DOCUMENT
  // =========================

  const handleSubmit = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");

    if (!customer) {
      setError("Customer information is not available.");
      return;
    }

    if (!formData.documentType) {
      setError("Please select a document type.");
      return;
    }

    if (!formData.documentNumber.trim()) {
      setError("Please enter document number.");
      return;
    }

    try {
      setSubmitting(true);

      const params = new URLSearchParams();

      params.append(
        "documentType",
        formData.documentType
      );

      params.append(
        "documentNumber",
        formData.documentNumber.trim()
      );

      const response = await fetch(
        `http://localhost:8080/api/kyc/upload/${customer.id}?${params.toString()}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      const responseData = await response.json();

      if (!response.ok) {
        throw new Error(
          responseData.message ||
            "Unable to submit KYC document."
        );
      }

      setMessage(
        "KYC document submitted successfully."
      );

      resetForm();

      await loadKycData();
    } catch (err) {
      console.error("KYC submission error:", err);
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  // =========================
  // STATUS BADGE
  // =========================

  const getStatusStyle = (status) => {
    const normalized =
      status?.toUpperCase();

    if (normalized === "VERIFIED") {
      return {
        background: "#eaf8ef",
        color: "#18723c",
        border: "1px solid #c8ecd5",
      };
    }

    if (normalized === "REJECTED") {
      return {
        background: "#fff0f0",
        color: "#b42318",
        border: "1px solid #ffd1d1",
      };
    }

    return {
      background: "#fff8e7",
      color: "#9a6700",
      border: "1px solid #f2dfaa",
    };
  };

  // =========================
  // LOADING
  // =========================

  if (loading) {
    return (
      <div style={styles.page}>
        <div style={styles.loadingContainer}>
          <div style={styles.loader}></div>

          <p>
            Loading KYC details...
          </p>
        </div>
      </div>
    );
  }

  // =========================
  // UI
  // =========================

  return (
    <div style={styles.page}>

      {/* =========================
          HEADER
      ========================= */}

      <div style={styles.header}>

        <div>
          <div style={styles.brand}>
            AVANI BANK
          </div>

          <h1 style={styles.title}>
            KYC Verification
          </h1>

          <p style={styles.subtitle}>
            Manage your identity verification
            documents securely.
          </p>
        </div>

        <button
          type="button"
          onClick={() => navigate("/dashboard")}
          style={styles.dashboardButton}
        >
          ← Dashboard
        </button>

      </div>

      {/* =========================
          MESSAGES
      ========================= */}

      {message && (
        <div style={styles.successMessage}>
          ✓ {message}
        </div>
      )}

      {error && (
        <div style={styles.errorMessage}>
          ⚠ {error}
        </div>
      )}

      {/* =========================
          KYC STATUS CARD
      ========================= */}

      <div style={styles.statusCard}>

        <div style={styles.statusIcon}>
          🛡️
        </div>

        <div style={styles.statusContent}>

          <div style={styles.statusLabel}>
            Overall KYC Status
          </div>

          <div
            style={{
              ...styles.statusBadge,
              ...getStatusStyle(
                customer?.kycStatus
              ),
            }}
          >
            {customer?.kycStatus ||
              "PENDING"}
          </div>

          <p style={styles.statusText}>
            {customer?.kycStatus ===
            "VERIFIED"
              ? "Your KYC verification has been successfully completed."
              : customer?.kycStatus ===
                "REJECTED"
              ? "Your KYC verification requires attention."
              : "Your KYC verification is currently pending."}
          </p>

        </div>

      </div>

      {/* =========================
          CUSTOMER DETAILS
      ========================= */}

      <div style={styles.card}>

        <h2 style={styles.cardTitle}>
          Account Information
        </h2>

        <div style={styles.customerGrid}>

          <div>
            <span style={styles.infoLabel}>
              Full Name
            </span>

            <strong style={styles.infoValue}>
              {customer?.fullName ||
                "Not available"}
            </strong>
          </div>

          <div>
            <span style={styles.infoLabel}>
              Email
            </span>

            <strong style={styles.infoValue}>
              {customer?.email ||
                "Not available"}
            </strong>
          </div>

          <div>
            <span style={styles.infoLabel}>
              Account Number
            </span>

            <strong style={styles.infoValue}>
              {customer?.accountNumber ||
                "Not available"}
            </strong>
          </div>

          <div>
            <span style={styles.infoLabel}>
              Account Type
            </span>

            <strong style={styles.infoValue}>
              {customer?.accountType ||
                "Not available"}
            </strong>
          </div>

        </div>

      </div>

      {/* =========================
          ADD DOCUMENT
      ========================= */}

      <div style={styles.card}>

        <div style={styles.cardHeader}>

          <div>
            <h2 style={styles.cardTitle}>
              Submit KYC Document
            </h2>

            <p style={styles.cardSubtitle}>
              Submit your identity document
              for verification.
            </p>
          </div>

          <div style={styles.secureBadge}>
            🔒 Secure
          </div>

        </div>

        <form onSubmit={handleSubmit}>

          <div style={styles.formGrid}>

            {/* Document Type */}

            <div style={styles.field}>

              <label style={styles.label}>
                Document Type
              </label>

              <select
                name="documentType"
                value={formData.documentType}
                onChange={handleChange}
                style={styles.input}
                required
              >
                <option value="">
                  Select document
                </option>

                <option value="PAN">
                  PAN Card
                </option>

                <option value="AADHAAR">
                  Aadhaar Card
                </option>

                <option value="PASSPORT">
                  Passport
                </option>

                <option value="VOTER_ID">
                  Voter ID
                </option>

                <option value="DRIVING_LICENSE">
                  Driving License
                </option>
              </select>

            </div>

            {/* Document Number */}

            <div style={styles.field}>

              <label style={styles.label}>
                Document Number
              </label>

              <input
                type="text"
                name="documentNumber"
                value={formData.documentNumber}
                onChange={handleChange}
                placeholder="Enter document number"
                style={styles.input}
                required
              />

            </div>

          </div>

          <div style={styles.formActions}>

            <button
              type="button"
              onClick={resetForm}
              style={styles.cancelButton}
              disabled={submitting}
            >
              Clear
            </button>

            <button
              type="submit"
              style={styles.submitButton}
              disabled={submitting}
            >
              {submitting
                ? "Submitting..."
                : "Submit Document"}
            </button>

          </div>

        </form>

      </div>

      {/* =========================
          DOCUMENT LIST
      ========================= */}

      <div style={styles.card}>

        <div style={styles.cardHeader}>

          <div>
            <h2 style={styles.cardTitle}>
              Submitted Documents
            </h2>

            <p style={styles.cardSubtitle}>
              Track the verification status of
              your submitted documents.
            </p>
          </div>

          <span style={styles.documentCount}>
            {documents.length} Document
            {documents.length !== 1
              ? "s"
              : ""}
          </span>

        </div>

        {documents.length === 0 ? (

          <div style={styles.emptyState}>

            <div style={styles.emptyIcon}>
              📄
            </div>

            <h3 style={styles.emptyTitle}>
              No KYC Documents
            </h3>

            <p style={styles.emptyText}>
              You haven't submitted any KYC
              documents yet.
            </p>

          </div>

        ) : (

          <div style={styles.documentList}>

            {documents.map((document) => (

              <div
                key={document.id}
                style={styles.documentCard}
              >

                <div style={styles.documentIcon}>
                  📄
                </div>

                <div style={styles.documentInfo}>

                  <h3 style={styles.documentName}>
                    {document.documentType}
                  </h3>

                  <p style={styles.documentNumber}>
                    Document No:{" "}
                    {document.documentNumber}
                  </p>

                  {document.verifiedAt && (
                    <p style={styles.verifiedDate}>
                      Verified:{" "}
                      {new Date(
                        document.verifiedAt
                      ).toLocaleString()}
                    </p>
                  )}

                  {document.verificationRemarks && (
                    <p style={styles.remarks}>
                      {document.verificationRemarks}
                    </p>
                  )}

                </div>

                <div
                  style={{
                    ...styles.documentStatus,
                    ...getStatusStyle(
                      document.verificationStatus
                    ),
                  }}
                >
                  {document.verificationStatus ||
                    "PENDING"}
                </div>

              </div>

            ))}

          </div>

        )}

      </div>

      {/* =========================
          INFORMATION
      ========================= */}

      <div style={styles.infoBox}>

        <div style={styles.infoBoxIcon}>
          ℹ️
        </div>

        <div>
          <strong style={styles.infoBoxTitle}>
            KYC Verification
          </strong>

          <p style={styles.infoBoxText}>
            Your submitted documents are reviewed
            by the bank verification system. Once
            verified, your KYC status will be updated
            automatically.
          </p>
        </div>

      </div>

    </div>
  );
}

// =====================================================
// STYLES
// =====================================================

const styles = {

  page: {
    minHeight: "100vh",
    background:
      "linear-gradient(135deg, #f4f7fb 0%, #eef3f9 100%)",
    padding: "32px",
    boxSizing: "border-box",
    fontFamily:
      "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    color: "#172033",
  },

  header: {
    maxWidth: "1150px",
    margin: "0 auto 25px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "20px",
  },

  brand: {
    fontSize: "12px",
    fontWeight: "800",
    letterSpacing: "2px",
    color: "#64748b",
    marginBottom: "6px",
  },

  title: {
    margin: "0",
    fontSize: "30px",
    fontWeight: "800",
    letterSpacing: "-0.7px",
  },

  subtitle: {
    margin: "7px 0 0",
    color: "#718096",
    fontSize: "14px",
  },

  dashboardButton: {
    border: "1px solid #d7dee9",
    background: "#ffffff",
    color: "#26344a",
    borderRadius: "10px",
    padding: "11px 17px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer",
    boxShadow:
      "0 4px 12px rgba(20, 35, 60, 0.06)",
    whiteSpace: "nowrap",
  },

  successMessage: {
    maxWidth: "1150px",
    margin: "0 auto 16px",
    padding: "13px 16px",
    borderRadius: "10px",
    background: "#eaf8ef",
    color: "#19713b",
    border: "1px solid #c9ecd6",
    fontSize: "13px",
    fontWeight: "600",
  },

  errorMessage: {
    maxWidth: "1150px",
    margin: "0 auto 16px",
    padding: "13px 16px",
    borderRadius: "10px",
    background: "#fff0f0",
    color: "#b42318",
    border: "1px solid #ffd2d2",
    fontSize: "13px",
    fontWeight: "600",
  },

  statusCard: {
    maxWidth: "1150px",
    margin: "0 auto 20px",
    padding: "22px",
    borderRadius: "16px",
    background: "#ffffff",
    border: "1px solid #e4e9f0",
    boxShadow:
      "0 8px 25px rgba(30, 45, 70, 0.06)",
    display: "flex",
    alignItems: "center",
    gap: "17px",
  },

  statusIcon: {
    width: "55px",
    height: "55px",
    borderRadius: "14px",
    background: "#edf4ff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "25px",
    flexShrink: 0,
  },

  statusContent: {
    flex: 1,
  },

  statusLabel: {
    color: "#7a8699",
    fontSize: "12px",
    fontWeight: "700",
    marginBottom: "6px",
  },

  statusBadge: {
    display: "inline-block",
    padding: "6px 11px",
    borderRadius: "7px",
    fontSize: "11px",
    fontWeight: "800",
    letterSpacing: "0.5px",
  },

  statusText: {
    margin: "8px 0 0",
    color: "#66748a",
    fontSize: "13px",
  },

  card: {
    maxWidth: "1150px",
    margin: "0 auto 20px",
    padding: "25px",
    background: "#ffffff",
    border: "1px solid #e4e9f0",
    borderRadius: "16px",
    boxShadow:
      "0 8px 25px rgba(30, 45, 70, 0.06)",
  },

  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "15px",
    marginBottom: "20px",
  },

  cardTitle: {
    margin: "0",
    fontSize: "19px",
    fontWeight: "800",
  },

  cardSubtitle: {
    margin: "5px 0 0",
    color: "#7a8699",
    fontSize: "13px",
  },

  secureBadge: {
    padding: "7px 10px",
    borderRadius: "7px",
    background: "#f1f7f3",
    color: "#277346",
    fontSize: "11px",
    fontWeight: "700",
    whiteSpace: "nowrap",
  },

  documentCount: {
    color: "#68768b",
    fontSize: "12px",
    fontWeight: "700",
  },

  customerGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(4, minmax(0, 1fr))",
    gap: "20px",
  },

  infoLabel: {
    display: "block",
    color: "#8894a6",
    fontSize: "11px",
    marginBottom: "5px",
  },

  infoValue: {
    display: "block",
    fontSize: "13px",
    color: "#26344a",
    wordBreak: "break-word",
  },

  formGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(2, minmax(0, 1fr))",
    gap: "18px",
  },

  field: {
    display: "flex",
    flexDirection: "column",
    gap: "7px",
  },

  label: {
    fontSize: "12px",
    fontWeight: "700",
    color: "#46536a",
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    border: "1px solid #d9e0ea",
    borderRadius: "9px",
    padding: "11px 12px",
    fontSize: "13px",
    outline: "none",
    background: "#fbfcfe",
    color: "#202b3c",
  },

  formActions: {
    marginTop: "22px",
    display: "flex",
    justifyContent: "flex-end",
    gap: "10px",
  },

  cancelButton: {
    border: "1px solid #d7dee8",
    background: "#ffffff",
    color: "#4c5a70",
    borderRadius: "9px",
    padding: "11px 18px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer",
  },

  submitButton: {
    border: "none",
    background: "#172b4d",
    color: "#ffffff",
    borderRadius: "9px",
    padding: "11px 20px",
    fontSize: "13px",
    fontWeight: "700",
    cursor: "pointer",
  },

  documentList: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },

  documentCard: {
    border: "1px solid #e6ebf2",
    borderRadius: "13px",
    padding: "17px",
    display: "flex",
    alignItems: "center",
    gap: "15px",
    background: "#fcfdff",
  },

  documentIcon: {
    width: "46px",
    height: "46px",
    borderRadius: "11px",
    background: "#edf3fb",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "21px",
    flexShrink: 0,
  },

  documentInfo: {
    flex: 1,
    minWidth: 0,
  },

  documentName: {
    margin: "0",
    fontSize: "15px",
    fontWeight: "800",
  },

  documentNumber: {
    margin: "4px 0",
    color: "#6d7a8e",
    fontSize: "12px",
  },

  verifiedDate: {
    margin: "3px 0",
    color: "#718096",
    fontSize: "11px",
  },

  remarks: {
    margin: "6px 0 0",
    color: "#59687d",
    fontSize: "11px",
    fontStyle: "italic",
  },

  documentStatus: {
    padding: "7px 10px",
    borderRadius: "7px",
    fontSize: "10px",
    fontWeight: "800",
    whiteSpace: "nowrap",
  },

  emptyState: {
    textAlign: "center",
    padding: "40px 20px",
  },

  emptyIcon: {
    width: "58px",
    height: "58px",
    margin: "0 auto 12px",
    borderRadius: "50%",
    background: "#f0f4fa",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "24px",
  },

  emptyTitle: {
    margin: "0",
    fontSize: "17px",
    fontWeight: "800",
  },

  emptyText: {
    margin: "7px 0 0",
    color: "#7b8799",
    fontSize: "13px",
  },

  infoBox: {
    maxWidth: "1150px",
    margin: "0 auto",
    padding: "17px",
    display: "flex",
    gap: "12px",
    alignItems: "flex-start",
    background: "#f5f8fc",
    border: "1px solid #e1e8f1",
    borderRadius: "12px",
  },

  infoBoxIcon: {
    fontSize: "18px",
  },

  infoBoxTitle: {
    fontSize: "12px",
    color: "#33435a",
  },

  infoBoxText: {
    margin: "4px 0 0",
    color: "#728096",
    fontSize: "11px",
    lineHeight: "1.6",
  },

  loadingContainer: {
    minHeight: "70vh",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    color: "#68768b",
    fontSize: "14px",
  },

  loader: {
    width: "28px",
    height: "28px",
    border: "3px solid #dce4ef",
    borderTop: "3px solid #172b4d",
    borderRadius: "50%",
    marginBottom: "12px",
    animation: "spin 1s linear infinite",
  },
};

export default KYC;
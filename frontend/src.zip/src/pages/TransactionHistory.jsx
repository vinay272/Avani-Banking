import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

function TransactionHistory() {
  const navigate = useNavigate();

  const [sentTransactions, setSentTransactions] = useState([]);
  const [receivedTransactions, setReceivedTransactions] = useState([]);

  const [activeFilter, setActiveFilter] = useState("ALL");
  const [search, setSearch] = useState("");

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // =========================
  // FETCH TRANSACTIONS
  // =========================

  useEffect(() => {
    const fetchTransactions = async () => {
      const token = localStorage.getItem("token");
       console.log("Transaction History Token:", token);  
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        setLoading(true);
        setError("");

        const headers = {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        };

        const [sentResponse, receivedResponse] = await Promise.all([
          fetch("http://localhost:8080/api/transactions/sent", {
            method: "GET",
            headers,
          }),

          fetch("http://localhost:8080/api/transactions/received", {
            method: "GET",
            headers,
          }),
        ]);

        if (
          sentResponse.status === 401 ||
          sentResponse.status === 403 ||
          receivedResponse.status === 401 ||
          receivedResponse.status === 403
        ) {
          localStorage.removeItem("token");
          localStorage.removeItem("customer");
          navigate("/login");
          return;
        }

        if (!sentResponse.ok) {
          throw new Error("Unable to fetch sent transactions");
        }

        if (!receivedResponse.ok) {
          throw new Error("Unable to fetch received transactions");
        }

        const sentData = await sentResponse.json();
        const receivedData = await receivedResponse.json();

        setSentTransactions(sentData || []);
        setReceivedTransactions(receivedData || []);
      } catch (err) {
        console.error("Transaction History Error:", err);

        setError(
          err.message || "Unable to load transaction history."
        );
      } finally {
        setLoading(false);
      }
    };

    fetchTransactions();
  }, [navigate]);

  // =========================
  // COMBINE TRANSACTIONS
  // =========================

  const allTransactions = useMemo(() => {
    const sent = sentTransactions.map((transaction) => ({
      ...transaction,
      direction: "SENT",
    }));

    const received = receivedTransactions.map((transaction) => ({
      ...transaction,
      direction: "RECEIVED",
    }));

    return [...sent, ...received].sort((a, b) => {
      const dateA = new Date(
        a.transactionDate || a.createdAt || 0
      ).getTime();

      const dateB = new Date(
        b.transactionDate || b.createdAt || 0
      ).getTime();

      return dateB - dateA;
    });
  }, [sentTransactions, receivedTransactions]);

  // =========================
  // FILTER + SEARCH
  // =========================

  const filteredTransactions = useMemo(() => {
    return allTransactions.filter((transaction) => {
      const matchesFilter =
        activeFilter === "ALL" ||
        transaction.direction === activeFilter;

      const searchText = search.toLowerCase().trim();

      if (!searchText) {
        return matchesFilter;
      }

      const sender =
        transaction.senderAccountNumber || "";

      const receiver =
        transaction.receiverAccountNumber || "";

      const type =
        transaction.transactionType || "";

      const status =
        transaction.status || "";

      const matchesSearch =
        sender.toLowerCase().includes(searchText) ||
        receiver.toLowerCase().includes(searchText) ||
        type.toLowerCase().includes(searchText) ||
        status.toLowerCase().includes(searchText) ||
        String(transaction.amount || "")
          .toLowerCase()
          .includes(searchText);

      return matchesFilter && matchesSearch;
    });
  }, [allTransactions, activeFilter, search]);

  // =========================
  // FORMAT DATE
  // =========================

  const formatDate = (dateValue) => {
    if (!dateValue) {
      return "Date unavailable";
    }

    const date = new Date(dateValue);

    if (Number.isNaN(date.getTime())) {
      return "Date unavailable";
    }

    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // =========================
  // FORMAT AMOUNT
  // =========================

  const formatAmount = (amount) => {
    return Number(amount || 0).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  // =========================
  // UI
  // =========================

  return (
    <div style={styles.page}>
      <div style={styles.container}>

        {/* HEADER */}
        <div style={styles.header}>

          <div>
            <p style={styles.smallTitle}>
              AVANI BANK
            </p>

            <h1 style={styles.title}>
              Transaction History
            </h1>

            <p style={styles.subtitle}>
              View and track all your account transactions.
            </p>
          </div>

          <div style={styles.headerIcon}>
            ↕
          </div>

        </div>

        {/* SUMMARY */}
        <div style={styles.summaryGrid}>

          <div style={styles.summaryCard}>
            <div style={styles.summaryIcon}>
              ↗
            </div>

            <div>
              <p style={styles.summaryLabel}>
                Money Sent
              </p>

              <h2 style={styles.summaryValue}>
                ₹
                {formatAmount(
                  sentTransactions.reduce(
                    (total, transaction) =>
                      total + Number(transaction.amount || 0),
                    0
                  )
                )}
              </h2>
            </div>
          </div>

          <div style={styles.summaryCard}>
            <div style={styles.summaryIcon}>
              ↙
            </div>

            <div>
              <p style={styles.summaryLabel}>
                Money Received
              </p>

              <h2 style={styles.summaryValue}>
                ₹
                {formatAmount(
                  receivedTransactions.reduce(
                    (total, transaction) =>
                      total + Number(transaction.amount || 0),
                    0
                  )
                )}
              </h2>
            </div>
          </div>

          <div style={styles.summaryCard}>
            <div style={styles.summaryIcon}>
              #
            </div>

            <div>
              <p style={styles.summaryLabel}>
                Total Transactions
              </p>

              <h2 style={styles.summaryValue}>
                {allTransactions.length}
              </h2>
            </div>
          </div>

        </div>

        {/* MAIN CARD */}
        <div style={styles.card}>

          {/* CARD HEADER */}
          <div style={styles.cardHeader}>

            <div>
              <h2 style={styles.cardTitle}>
                All Transactions
              </h2>

              <p style={styles.cardSubtitle}>
                Your latest account activity
              </p>
            </div>

            <button
              onClick={() => navigate("/dashboard")}
              style={styles.backButton}
            >
              ← Dashboard
            </button>

          </div>

          {/* FILTERS */}
          <div style={styles.filterRow}>

            <div style={styles.tabs}>

              {["ALL", "SENT", "RECEIVED"].map(
                (filter) => (
                  <button
                    key={filter}
                    onClick={() =>
                      setActiveFilter(filter)
                    }
                    style={{
                      ...styles.tab,
                      ...(activeFilter === filter
                        ? styles.activeTab
                        : {}),
                    }}
                  >
                    {filter === "ALL"
                      ? "All"
                      : filter === "SENT"
                      ? "Sent"
                      : "Received"}
                  </button>
                )
              )}

            </div>

            <input
              type="text"
              placeholder="Search transactions..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              style={styles.search}
            />

          </div>

          {/* ERROR */}
          {error && (
            <div style={styles.error}>
              ⚠ {error}
            </div>
          )}

          {/* LOADING */}
          {loading ? (
            <div style={styles.emptyState}>
              <div style={styles.loader}>
                ⟳
              </div>

              <h3 style={styles.emptyTitle}>
                Loading transactions...
              </h3>

              <p style={styles.emptyText}>
                Please wait while we fetch your
                transaction history.
              </p>
            </div>
          ) : filteredTransactions.length === 0 ? (

            /* EMPTY */
            <div style={styles.emptyState}>

              <div style={styles.emptyIcon}>
                ₹
              </div>

              <h3 style={styles.emptyTitle}>
                No transactions found
              </h3>

              <p style={styles.emptyText}>
                {search
                  ? "No transactions match your search."
                  : "Your transaction history will appear here."}
              </p>

            </div>

          ) : (

            /* TRANSACTION LIST */
            <div style={styles.transactionList}>

              {filteredTransactions.map(
                (transaction, index) => {

                  const isSent =
                    transaction.direction === "SENT";

                  const accountNumber = isSent
                    ? transaction.receiverAccountNumber
                    : transaction.senderAccountNumber;

                  return (
                    <div
                      key={
                        transaction.id ||
                        `${transaction.direction}-${index}`
                      }
                      style={styles.transactionRow}
                    >

                      <div
                        style={{
                          ...styles.transactionIcon,
                          background: isSent
                            ? "#fff1f1"
                            : "#ecf9f1",
                          color: isSent
                            ? "#d14343"
                            : "#168653",
                        }}
                      >
                        {isSent ? "↗" : "↙"}
                      </div>

                      <div style={styles.transactionInfo}>

                        <div style={styles.transactionTop}>

                          <h3
                            style={
                              styles.transactionTitle
                            }
                          >
                            {isSent
                              ? "Money Sent"
                              : "Money Received"}
                          </h3>

                          <span
                            style={{
                              ...styles.amount,
                              color: isSent
                                ? "#d14343"
                                : "#168653",
                            }}
                          >
                            {isSent ? "-" : "+"}₹
                            {formatAmount(
                              transaction.amount
                            )}
                          </span>

                        </div>

                        <div
                          style={
                            styles.transactionBottom
                          }
                        >

                          <span>
                            {isSent
                              ? "To"
                              : "From"}{" "}
                            <strong>
                              {accountNumber ||
                                "Unknown Account"}
                            </strong>
                          </span>

                          <span>
                            {formatDate(
                              transaction.transactionDate ||
                                transaction.createdAt
                            )}
                          </span>

                          <span
                            style={{
                              ...styles.status,
                              background:
                                transaction.status ===
                                "SUCCESS"
                                  ? "#eaf8f0"
                                  : "#fff4df",
                              color:
                                transaction.status ===
                                "SUCCESS"
                                  ? "#168653"
                                  : "#a66a00",
                            }}
                          >
                            {transaction.status ||
                              "UNKNOWN"}
                          </span>

                        </div>

                      </div>

                    </div>
                  );
                }
              )}

            </div>
          )}

        </div>

      </div>
    </div>
  );
}

const styles = {

  page: {
    minHeight: "100vh",
    background: "#f5f7fb",
    fontFamily: "Inter, Arial, sans-serif",
    color: "#172033",
  },

  container: {
    width: "100%",
    maxWidth: "1000px",
    margin: "0 auto",
    padding: "35px 20px",
    boxSizing: "border-box",
  },

  header: {
    background:
      "linear-gradient(135deg, #102354 0%, #173b8c 55%, #2457c6 100%)",
    color: "white",
    borderRadius: "20px",
    padding: "30px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "20px",
    boxShadow:
      "0 15px 35px rgba(18,51,120,0.18)",
  },

  smallTitle: {
    margin: 0,
    fontSize: "11px",
    letterSpacing: "2px",
    opacity: 0.7,
    fontWeight: "700",
  },

  title: {
    margin: "8px 0 5px",
    fontSize: "30px",
  },

  subtitle: {
    margin: 0,
    fontSize: "13px",
    color: "#d7e2ff",
  },

  headerIcon: {
    width: "55px",
    height: "55px",
    borderRadius: "15px",
    background: "rgba(255,255,255,0.13)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "25px",
    flexShrink: 0,
  },

  summaryGrid: {
    display: "grid",
    gridTemplateColumns:
      "repeat(3, minmax(0, 1fr))",
    gap: "15px",
    marginTop: "20px",
  },

  summaryCard: {
    background: "white",
    border: "1px solid #e9edf4",
    borderRadius: "15px",
    padding: "20px",
    display: "flex",
    alignItems: "center",
    gap: "14px",
    boxShadow:
      "0 6px 20px rgba(20,35,70,0.05)",
  },

  summaryIcon: {
    width: "42px",
    height: "42px",
    borderRadius: "11px",
    background: "#edf3ff",
    color: "#173b8c",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "20px",
    fontWeight: "700",
    flexShrink: 0,
  },

  summaryLabel: {
    margin: 0,
    fontSize: "11px",
    color: "#8993a8",
    fontWeight: "600",
  },

  summaryValue: {
    margin: "4px 0 0",
    fontSize: "20px",
    color: "#172033",
  },

  card: {
    background: "white",
    marginTop: "20px",
    borderRadius: "18px",
    border: "1px solid #e9edf4",
    padding: "25px",
    boxShadow:
      "0 8px 30px rgba(20,35,70,0.06)",
  },

  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "15px",
    marginBottom: "22px",
  },

  cardTitle: {
    margin: 0,
    fontSize: "20px",
  },

  cardSubtitle: {
    margin: "5px 0 0",
    fontSize: "12px",
    color: "#8993a8",
  },

  backButton: {
    border: "1px solid #dfe5ee",
    background: "#fff",
    color: "#173b8c",
    borderRadius: "9px",
    padding: "10px 14px",
    fontSize: "12px",
    fontWeight: "700",
    cursor: "pointer",
  },

  filterRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "15px",
    marginBottom: "20px",
    flexWrap: "wrap",
  },

  tabs: {
    display: "flex",
    gap: "6px",
    background: "#f5f7fb",
    padding: "5px",
    borderRadius: "10px",
  },

  tab: {
    border: "none",
    background: "transparent",
    color: "#68748a",
    padding: "9px 14px",
    borderRadius: "7px",
    fontSize: "12px",
    fontWeight: "600",
    cursor: "pointer",
  },

  activeTab: {
    background: "white",
    color: "#173b8c",
    boxShadow:
      "0 2px 8px rgba(20,35,70,0.08)",
  },

  search: {
    width: "230px",
    height: "40px",
    border: "1px solid #dfe5ee",
    borderRadius: "9px",
    padding: "0 12px",
    outline: "none",
    fontSize: "12px",
    boxSizing: "border-box",
  },

  error: {
    background: "#fff0f0",
    color: "#d13c3c",
    padding: "12px 14px",
    borderRadius: "9px",
    fontSize: "12px",
    marginBottom: "15px",
  },

  transactionList: {
    display: "flex",
    flexDirection: "column",
  },

  transactionRow: {
    display: "flex",
    alignItems: "center",
    gap: "15px",
    padding: "17px 5px",
    borderBottom: "1px solid #eef1f5",
  },

  transactionIcon: {
    width: "43px",
    height: "43px",
    borderRadius: "12px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "20px",
    fontWeight: "700",
    flexShrink: 0,
  },

  transactionInfo: {
    width: "100%",
    minWidth: 0,
  },

  transactionTop: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "15px",
  },

  transactionTitle: {
    margin: 0,
    fontSize: "14px",
    color: "#25304a",
  },

  amount: {
    fontSize: "14px",
    fontWeight: "800",
    whiteSpace: "nowrap",
  },

  transactionBottom: {
    display: "flex",
    alignItems: "center",
    gap: "15px",
    marginTop: "7px",
    fontSize: "10px",
    color: "#8993a8",
    flexWrap: "wrap",
  },

  status: {
    padding: "4px 8px",
    borderRadius: "6px",
    fontSize: "9px",
    fontWeight: "700",
  },

  emptyState: {
    textAlign: "center",
    padding: "60px 20px",
  },

  emptyIcon: {
    width: "55px",
    height: "55px",
    margin: "0 auto 15px",
    borderRadius: "16px",
    background: "#edf3ff",
    color: "#173b8c",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "23px",
    fontWeight: "700",
  },

  loader: {
    fontSize: "30px",
    color: "#173b8c",
    marginBottom: "15px",
  },

  emptyTitle: {
    margin: 0,
    fontSize: "16px",
  },

  emptyText: {
    margin: "7px 0 0",
    color: "#8993a8",
    fontSize: "12px",
  },
};

export default TransactionHistory;
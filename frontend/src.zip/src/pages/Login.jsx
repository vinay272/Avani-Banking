import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

function Login() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      const response = await api.post("/auth/login", formData);

      console.log("Login Response:", response.data);

      // JWT token save
      localStorage.setItem("token", response.data.token);

      // Customer information save
      localStorage.setItem(
        "customer",
        JSON.stringify(response.data.customer)
      );

      // Dashboard par bhejo
      navigate("/dashboard");

    } catch (error) {
      console.error("Login Error:", error);

      if (error.response) {
        setError(
          error.response.data?.message ||
          "Invalid email or password"
        );
      } else {
        setError("Unable to connect with server");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>

        <div style={styles.logo}>
          🏦
        </div>

        <h1 style={styles.title}>Avani Bank</h1>

        <p style={styles.subtitle}>
          Welcome back! Login to your account
        </p>

        <form onSubmit={handleSubmit}>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Email</label>

            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Password</label>

            <input
              type="password"
              name="password"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>

          {error && (
            <div style={styles.error}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={styles.button}
          >
            {loading ? "Logging in..." : "Login"}
          </button>

        </form>
      <div style={styles.registerSection}>

  <span style={styles.registerText}>
    Don't have an account?
  </span>

  <button
    type="button"
    onClick={() => navigate("/register")}
    style={styles.registerButton}
  >
    Create New Account
  </button>

    </div>  
        <p style={styles.footer}>
          Secure Banking • Avani Bank
        </p>

      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background:
      "linear-gradient(135deg, #0f172a, #1e3a8a, #312e81)",
    padding: "20px",
  },

  card: {
    width: "100%",
    maxWidth: "420px",
    background: "#ffffff",
    padding: "40px",
    borderRadius: "20px",
    boxShadow: "0 20px 50px rgba(0,0,0,0.25)",
  },

  logo: {
    textAlign: "center",
    fontSize: "48px",
    marginBottom: "10px",
  },

  title: {
    textAlign: "center",
    margin: "0",
    color: "#1e3a8a",
    fontSize: "32px",
  },

  subtitle: {
    textAlign: "center",
    color: "#64748b",
    marginBottom: "30px",
  },

  inputGroup: {
    marginBottom: "20px",
  },

  label: {
    display: "block",
    marginBottom: "8px",
    fontWeight: "600",
    color: "#334155",
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    padding: "13px",
    border: "1px solid #cbd5e1",
    borderRadius: "10px",
    fontSize: "15px",
    outline: "none",
  },

  button: {
    width: "100%",
    padding: "14px",
    border: "none",
    borderRadius: "10px",
    background: "#1e3a8a",
    color: "#ffffff",
    fontSize: "16px",
    fontWeight: "600",
    cursor: "pointer",
    marginTop: "10px",
  },
  registerSection: {
  textAlign: "center",
  marginTop: "20px",
  paddingTop: "18px",
  borderTop: "1px solid #e2e8f0",
},

registerText: {
  color: "#64748b",
  fontSize: "13px",
},

registerButton: {
  border: "none",
  background: "transparent",
  color: "#1e3a8a",
  fontWeight: "700",
  marginLeft: "6px",
  cursor: "pointer",
  fontSize: "13px",
},

  error: {
    background: "#fee2e2",
    color: "#b91c1c",
    padding: "10px",
    borderRadius: "8px",
    marginBottom: "15px",
    fontSize: "14px",
  },

  footer: {
    textAlign: "center",
    marginTop: "25px",
    color: "#94a3b8",
    fontSize: "13px",
  },
};

export default Login;
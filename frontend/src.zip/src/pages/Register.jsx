import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

function Register() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    accountType: "SAVINGS",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [accountNumber, setAccountNumber] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setSuccess("");
    setAccountNumber("");

    if (formData.phone.length !== 10) {
      setError("Please enter a valid 10-digit phone number.");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must contain at least 6 characters.");
      return;
    }

    try {
      setLoading(true);

      const response = await api.post(
        "/auth/register",
        formData
      );

      console.log("Register Response:", response.data);

      setSuccess(
        "Account created successfully! Please save your account number."
      );

      setAccountNumber(
        response.data.accountNumber
      );

      setFormData({
        fullName: "",
        email: "",
        phone: "",
        password: "",
        accountType: "SAVINGS",
      });

    } catch (error) {
      console.error("Register Error:", error);

      if (error.response) {
        setError(
          error.response.data?.message ||
          error.response.data ||
          "Registration failed."
        );
      } else {
        setError("Unable to connect with server.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>

      <div style={styles.card}>

        <div style={styles.logo}>
          🏦
        </div>

        <h1 style={styles.title}>
          Create Account
        </h1>

        <p style={styles.subtitle}>
          Open your Avani Bank account
        </p>

        <form onSubmit={handleSubmit}>

          {/* FULL NAME */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              Full Name
            </label>

            <input
              type="text"
              name="fullName"
              placeholder="Enter your full name"
              value={formData.fullName}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>

          {/* EMAIL */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              Email Address
            </label>

            <input
              type="email"
              name="email"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>

          {/* PHONE */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              Phone Number
            </label>

            <input
              type="tel"
              name="phone"
              placeholder="Enter 10-digit phone number"
              value={formData.phone}
              onChange={(e) => {
                const value = e.target.value.replace(
                  /\D/g,
                  ""
                );

                if (value.length <= 10) {
                  setFormData({
                    ...formData,
                    phone: value,
                  });
                }
              }}
              required
              style={styles.input}
            />
          </div>

          {/* PASSWORD */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              Password
            </label>

            <input
              type="password"
              name="password"
              placeholder="Create a password"
              value={formData.password}
              onChange={handleChange}
              required
              style={styles.input}
            />
          </div>

          {/* ACCOUNT TYPE */}
          <div style={styles.inputGroup}>
            <label style={styles.label}>
              Account Type
            </label>

            <select
              name="accountType"
              value={formData.accountType}
              onChange={handleChange}
              style={styles.input}
            >
              <option value="SAVINGS">
                Savings Account
              </option>

              <option value="CURRENT">
                Current Account
              </option>
            </select>
          </div>

          {/* SUCCESS */}
          {success && (
            <div style={styles.success}>
              <div>✓ {success}</div>

              {accountNumber && (
                <div style={styles.accountNumber}>
                  Account Number: {accountNumber}
                </div>
              )}
            </div>
          )}

          {/* ERROR */}
          {error && (
            <div style={styles.error}>
              ⚠ {error}
            </div>
          )}

          {/* BUTTON */}
          <button
            type="submit"
            disabled={loading}
            style={{
              ...styles.button,
              opacity: loading ? 0.7 : 1,
            }}
          >
            {loading
              ? "Creating Account..."
              : "Create Account →"}
          </button>

        </form>

        {/* LOGIN LINK */}
        <div style={styles.loginSection}>

          <span style={styles.loginText}>
            Already have an account?
          </span>

          <button
            type="button"
            onClick={() => navigate("/login")}
            style={styles.loginButton}
          >
            Login
          </button>

        </div>

        <p style={styles.footer}>
          Secure Banking • Avani Bank
        </p>

      </div>

    </div>
  );
}

const styles = {

  page: {
    minHeight: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background:
      "linear-gradient(135deg, #0f172a, #1e3a8a, #312e81)",
    padding: "30px 20px",
    boxSizing: "border-box",
  },

  card: {
    width: "100%",
    maxWidth: "460px",
    background: "#ffffff",
    padding: "40px",
    borderRadius: "22px",
    boxShadow:
      "0 20px 60px rgba(0,0,0,0.25)",
    boxSizing: "border-box",
  },

  logo: {
    textAlign: "center",
    fontSize: "45px",
    marginBottom: "8px",
  },

  title: {
    textAlign: "center",
    margin: 0,
    color: "#1e3a8a",
    fontSize: "30px",
  },

  subtitle: {
    textAlign: "center",
    color: "#64748b",
    marginTop: "8px",
    marginBottom: "28px",
    fontSize: "14px",
  },

  inputGroup: {
    marginBottom: "17px",
  },

  label: {
    display: "block",
    marginBottom: "7px",
    fontWeight: "600",
    color: "#334155",
    fontSize: "13px",
  },

  input: {
    width: "100%",
    boxSizing: "border-box",
    padding: "13px",
    border: "1px solid #cbd5e1",
    borderRadius: "10px",
    fontSize: "14px",
    outline: "none",
    background: "#000000",
  },

  button: {
    width: "100%",
    padding: "14px",
    border: "none",
    borderRadius: "10px",
    background:
      "linear-gradient(135deg, #1e3a8a, #2563c7)",
    color: "#ffffff",
    fontSize: "15px",
    fontWeight: "700",
    cursor: "pointer",
    marginTop: "5px",
  },

  success: {
    background: "#ecfdf5",
    border: "1px solid #a7f3d0",
    color: "#047857",
    padding: "12px",
    borderRadius: "9px",
    marginBottom: "15px",
    fontSize: "13px",
    lineHeight: "1.6",
  },

  accountNumber: {
    marginTop: "5px",
    fontSize: "16px",
    fontWeight: "700",
    letterSpacing: "1px",
  },

  error: {
    background: "#fee2e2",
    color: "#b91c1c",
    padding: "11px",
    borderRadius: "8px",
    marginBottom: "15px",
    fontSize: "13px",
  },

  loginSection: {
    textAlign: "center",
    marginTop: "22px",
    paddingTop: "20px",
    borderTop: "1px solid #e2e8f0",
  },

  loginText: {
    color: "#64748b",
    fontSize: "13px",
  },

  loginButton: {
    border: "none",
    background: "transparent",
    color: "#1e3a8a",
    fontWeight: "700",
    marginLeft: "6px",
    cursor: "pointer",
    fontSize: "13px",
  },

  footer: {
    textAlign: "center",
    marginTop: "20px",
    color: "#94a3b8",
    fontSize: "12px",
  },
};

export default Register;